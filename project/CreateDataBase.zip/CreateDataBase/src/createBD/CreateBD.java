package createBD;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



public class CreateBD {
	
	/**
	 * tabResponsable : contient les données de connexion de l'administrateur
	 * tabBudget : contient le budget
	 * tabUtilisateur: contient les données de tous les clients
	 * tabLivre: contient les détails des livres déjà commandés
	 * tabCommande et tabDetail contiennent les details des commandes
	 * 
	 */
	public static String tabResponsable= "CREATE TABLE RESPONSABLE( USER char(32) not null,PASS char(32) not null,EMAIL char(32) not null, NOM char(32) not null,primary key (USER,PASS));"; 
	public static String tabBudget="CREATE TABLE REVENU(BUDGET DOUBLE not null,Primary key(BUDGET),);";
	public static String tabUtilisateur="CREATE TABLE UTILISATEUR ( ID_PROF int not null AUTO_INCREMENT, NOM char(32) not null, PRENOM char(15) not null, EMAIL char(32) not null, primary key (ID_PROF));";
	public static String tabLivre="CREATE TABLE LIVRES ( ISBN char(50) not null, TITRE char(80) not null, AUTEUR char(50) not null, primary key (ISBN),);";
	public static String tabCommande="CREATE TABLE COMMANDE ( NUM_COM int not null AUTO_INCREMENT, ID_PROF char(10) not null , DATE_COMMANDE date not null,QUANTITE int not null, DATE_VALIDATION date, DATE_ACQUIS date,   primary key (NUM_COM), foreign key(ID_PROF) references UTILISATEUR );";
	public static String tabDetail="CREATE TABLE DETAIL ( NUM_COM int not null, ISBN char(50) not null, PRIX double not null, DESTINATION char(10) not null, COTEBUMP char(20), URGENCE char(25),URL char(255), TYPE char(255), primary key (NUM_COM, ISBN), foreign key(NUM_COM) references COMMANDE, foreign key(ISBN) references LIVRES );";
	
	
	/**
	 * pre : -
	 * post : l'application est connectée à la base de données
	 * @return
	 */
	public static java.sql.Connection connectMy(){
		java.sql.Connection connexion=null ;
		try{
			 Class.forName("org.h2.Driver");
			 connexion = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa","");
			 System.out.println("hello");
	        }catch(ClassNotFoundException e){System.out.print("erreur du driver");}
	         catch(SQLException e){System.out.print("erreur de connection");}
		return connexion;
		}
	public static void creerlestables(){
		
			java.sql.Connection connexion=connectMy();
	        try {       	
	            PreparedStatement preparedStatement1 = connexion.prepareStatement(tabResponsable); 
	            PreparedStatement preparedStatement2 = connexion.prepareStatement(tabUtilisateur); 
	            PreparedStatement preparedStatement3 = connexion.prepareStatement(tabBudget);
	            PreparedStatement preparedStatement4 = connexion.prepareStatement(tabLivre);
	            PreparedStatement preparedStatement5 = connexion.prepareStatement(tabCommande);
	            PreparedStatement preparedStatement6 = connexion.prepareStatement(tabDetail);
	            
	            preparedStatement1.executeUpdate();
	            preparedStatement2.executeUpdate();
	            preparedStatement3.executeUpdate();
	            preparedStatement4.executeUpdate();
	            preparedStatement5.executeUpdate();
	            preparedStatement6.executeUpdate();
	                     
	            connexion.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}
	/**
	 * InitialisationBudget permet de mettre à jour le budget
	 * @param budget 
	 */
	public static void InitialisationBudget(Float budget){
		
		java.sql.Connection connexion=connectMy();
        try {       	
            PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO REVENU(BUDGET) VALUES(?);"); 
            preparedStatement.setFloat(1,(float) budget);            
            preparedStatement.executeUpdate();                    
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	/**
	 * InitialisationResp permet de sauvegarder les données de l'administrateur, lors de la création de la base de données.
	 * @param user est le username de l'administrateur
	 * @param pass est le mot de passe de l'administrateur
	 * @param email est l'adresse mail
	 * @param nom est le nom de l'administrateur
	 */
	public static void InitialisationResp(String user, String pass, String email,String nom){
		
		java.sql.Connection connexion=connectMy();
        try {       	
            PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO RESPONSABLE(USER,PASS,EMAIL,NOM) VALUES(?,?,?,?);"); 
            preparedStatement.setString(1,user); 
            preparedStatement.setString(2,pass);
            preparedStatement.setString(3,email);
            preparedStatement.setString(4,nom);
            preparedStatement.executeUpdate();                    
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	/*public static void main(String[] args) {
		java.sql.Connection ct =connectMy();
		//creerlestables();
		InitialisationBudget((float) 100.0);
	}*/
	
}
