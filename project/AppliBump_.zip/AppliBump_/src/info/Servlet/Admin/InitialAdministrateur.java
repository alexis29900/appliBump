package info.Servlet.Admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Mail.Email;
import ManipulationBD.Budget;
import ManipulationBD.RecupererLesDonnees;
import ManipulationBD.TesterLesDonnees;
import RequetesEtMessage.Requete;

/**
 * Servlet implementation class InitialAdministrateur
 */
@WebServlet("/InitialAdministrateur")
public class InitialAdministrateur extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InitialAdministrateur() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nom = request.getParameter("nom");
		String pass = request.getParameter("pass");
		
		if(TesterLesDonnees.ConnexionAdmin(nom, pass)){
			
			//on affiche le budget à l'ecran
			Float budget = Budget.VOIRBUDGET();
			request.setAttribute("budget", budget);
			String message="";
			request.setAttribute("message", message);
			
			//statistique
			int New = RecupererLesDonnees.ResumerCommande(Requete.requete4);
			int Valider = RecupererLesDonnees.ResumerCommande(Requete.requete5);
			
			request.setAttribute("New", New);
			request.setAttribute("Valider", Valider);
			
			if(New > 30){
				//notification au responsable au cas ou on a 30 nouvelles commandes, en lui envoyant un mail
				String messageAenvoyer = Requete.message5(TesterLesDonnees.AdresseUserNameAdmin());
				String sujet= Requete.titre5;
				try{
					Email.sendEmail(TesterLesDonnees.AdresseMailAdmin(), sujet, messageAenvoyer);
				}
				catch(Exception e){}
			}
		
		this.getServletContext().getRequestDispatcher( "/WEB-INF/AccueilAdmin.jsp").forward( request, response );
						
		}
		else{
			
			String error ="Echec de connexion !!!";
			request.setAttribute("error", error);
			
			this.getServletContext().getRequestDispatcher( "/index.jsp").forward( request, response );
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
