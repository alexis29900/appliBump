package ManipulationBD;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



import Beans.MonFormulaire;


/** connexion à la base de donnée
 * @author mariejessica
 *
 */
public class Connexion {

	/**
	 * connexion à la base de donnée
	 * @return statut de la connexion
	 */

	public static java.sql.Connection connectMy(){
		java.sql.Connection connexion=null ;
		try{
			 Class.forName("org.h2.Driver");
			 connexion = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa","");
			 /*System.out.println("hello");*/
	        }catch(ClassNotFoundException e){}/*{System.out.print("erreur du driver");}*/
	         catch(SQLException e){}/*{System.out.print("erreur de connection");}*/
		return connexion;
		}
	
	/**
	 * ajouter les identités du client
	 * @param nom indique le nom de la personne ayant passé une commande
	 * @param prenom indique le prenom de la personne ayant passé une commande
	 * @param email indique le mail de la personne ayant passé une commande
	 * pre : une nouvelle commande vient d'etre envoyé
	 * post : les identités du client ont était ajouté dans la base de données et on l'attribue un  identifiant
	 */
	
	public static void AjoutUtil(String nom, String prenom, String email){
		java.sql.Connection connexion=connectMy();
        try {       	
            PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO UTILISATEUR(NOM,PRENOM,EMAIL) VALUES(?, ?,?);");
            preparedStatement.setString(1,nom);
            preparedStatement.setString(2, prenom);
            preparedStatement.setString(3, email);
            preparedStatement.executeUpdate();
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
 /**
  * Attribuer un numero de commande  d'un client
  * @param identCli est l'dentifiant du client
  * @param f contient les données remplies par le client sur le formulaire
  * pre: le client à un identifiant
  * post : on attribue à la commande un numéro
  */
	public static void AjoutCOM(int identCli, MonFormulaire f){
		java.sql.Connection connexion= connectMy();
        try {       	
            PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO COMMANDE(ID_PROF,DATE_COMMANDE,QUANTITE) VALUES(?, ?,?);");
            preparedStatement.setInt(1,identCli);
            preparedStatement.setString(2, f.getDatecom());
            preparedStatement.setInt(3, f.getQuantity());        
            preparedStatement.executeUpdate();
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	/**
	 * Ajouter un livre dans la base de donnée
	 * @param f contient les données remplies par le client sur le formulaire
	 * pre : /
	 * post : les détails d'un nouveau livre sont sauvergardés
	 */
	public static void AjoutLIVRE(MonFormulaire f){
		java.sql.Connection connexion= connectMy();
        try {       	
            PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO LIVRES(ISBN,TITRE,AUTEUR) VALUES(?, ?,?);");
            preparedStatement.setString(1, f.getISBN13());
            preparedStatement.setString(2, f.getBook());
            preparedStatement.setString(3, "MARIE");
            
            preparedStatement.executeUpdate();
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	/**
	 * 
	 * @param key indique le numero d'une commande
	 * @param f le formulaire rempli
	 * pre : le client et les details du livre sont sauvegardés
	 * post : commande sauvegardée
	 */
	public static void AjoutCOMPLEMENT(int key, MonFormulaire f){
		java.sql.Connection connexion=connectMy();
        try {       	
        	 PreparedStatement prepared = connexion.prepareStatement("INSERT INTO DETAIL (NUM_COM,ISBN,PRIX,DESTINATION,COTEBUMP,URGENCE,URL,TYPE) VALUES(?,?,?,?,?,?,?,?);");
             prepared.setInt(1,key);
             prepared.setString(2,f.getISBN13());
             prepared.setFloat(3,f.getPrix());                
             prepared.setString(4,f.getDestination());
             prepared.setString(5,f.getCoteBump());  
             prepared.setString(6,f.getUrgent());  
             prepared.setString(7, f.getUrl());
             prepared.setString(8,f.getStatut());
             prepared.executeUpdate();
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}   
	/**
	 * Modifier la quantité au sein d'une commande
	 * @param qte la nouvelle quantité
	 * @param numcom le numéro de la commande
	 */
	public static void MODIFYQAUNTITE( int qte, int numcom){
		java.sql.Connection connexion=Connexion.connectMy();
        try {       	
            PreparedStatement preparedStatement = connexion.prepareStatement("UPDATE COMMANDE set QUANTITE ='"+qte+"' WHERE NUM_COM = '" +numcom+"'");
            preparedStatement.executeUpdate();
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	/**
	 * Modifier le prix d'un livre
	 * @param price le prix
	 * @param numcom le numero de la commande
	 */
	public static void MODIFYPRICE(Float price, int numcom){
		java.sql.Connection connexion=Connexion.connectMy();
        try {       	
            PreparedStatement preparedStatement = connexion.prepareStatement("UPDATE DETAIL set PRIX ='"+price+"' WHERE NUM_COM = '"+numcom+"'");
            preparedStatement.executeUpdate();
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	

	/**
	 * 
	 * @param f est un formulaire, il contient tous les données saisies par le client 
	 * pre : une nouvelle commande vient d'etre passée
	 * post : la commande a été enregistrée dans la base de donnée
	 */
	
	public static void AjouterFormulaire(MonFormulaire f){
		
		//recherche permettant de savoir si le client est déjà dans la base de donnée
		 int numerocli = TesterLesDonnees.TROUVERIDENTIFIANT(f.getNom(), f.getPrenom());
		/* System.out.println(numerocli);*/
		 
		 //dans le cas ou , il n'y est pas
		 if(numerocli == 0){
			 AjoutUtil(f.getNom(),f.getPrenom(),f.getEmail());
			 numerocli = TesterLesDonnees.TROUVERIDENTIFIANT(f.getNom(), f.getPrenom());
			 /*System.out.println(numerocli);*/
			 AjoutCOM(numerocli,f);
			 if(!(TesterLesDonnees.VerifierLIVRE(f.getISBN13()))){
				 AjoutLIVRE(f);
			 }
			 int numerocommande = TesterLesDonnees.TROUVERNUMEROCOMMANDE(numerocli, f.getNom(), f.getPrenom());
			 /*System.out.println(numerocommande);*/
			 AjoutCOMPLEMENT(numerocommande,f);
			 
		 }
		 //sinon
		 else{
			 if(!(TesterLesDonnees.VerifierLIVRE(f.getISBN13()))){
				 AjoutLIVRE(f);
			 }
			 int numerocommande = TesterLesDonnees.TROUVERNUMEROCOMMANDE(numerocli, f.getNom(), f.getPrenom());
			 String isbn = RecupererLesDonnees.ISBNcommande(numerocommande);
			 if(isbn.equals(f.getISBN13())){
				 MODIFYQAUNTITE(f.getQuantity(), numerocommande);
				 MODIFYPRICE(f.getPrix(),numerocommande);    				 
			 }
			 else{
				 AjoutCOM(numerocli,f);
				 numerocommande = TesterLesDonnees.TROUVERNUMEROCOMMANDE(numerocli, f.getNom(), f.getPrenom());
   			 AjoutCOMPLEMENT(numerocommande,f);
			 }
		 }
		
	}
	
	
	
			
	
	
	/*
	  public static void main(String[] args) {
	 
		// TODO Auto-generated method stub

		 String nom = "ntumb";
		 String prenom = "marie";
		 String email = "jessicamwinkeu@yahoo.fr";
		 
		 String ISBN13 = "1234567890";
		 Float prix = (float) 20.0;
		 String book = "zéro est neutre"; 
		 String url = "www.google.com";
		 
		 int quantity = 4;
		 String valeur = "oui";
		 String statut = "déjà commandé";
		 String coteBump = "abc";
		 String destination = "faculté";
		
		 
		// on cr�e l'objet en passant en param�tre une cha�ne representant le format 
		 SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd" ); 
		 //récupération de la date courante 
		 Date currentTime_1 = new Date(); 
		 //on crée la cha�ne à partir de la date  
		 String datecom = formatter.format(currentTime_1);
		
		 
		 // création d'un bean utilisateur et initialisation avec les données récupérées sur le formulaire
		 MonFormulaire prof = new MonFormulaire();
		 prof.setNom(nom);
		 prof.setPrenom(prenom);
		 prof.setEmail(email);		 
		 
		 prof.setISBN13(ISBN13);
		 prof.setPrix(prix);
		 prof.setBook(book);
		 	  
		 prof.setQuantity(quantity);  
		 prof.setDatecom(datecom);
		 prof.setUrgent(valeur);
		 prof.setStatut(statut);
		 prof.setCoteBump(coteBump);
		 prof.setDestination(destination);
		 prof.setUrl(url);
		 
		 AjouterFormulaire(prof);
	}
	*/

}
