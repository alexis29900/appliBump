package CreateTableInit;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import createBD.CreateBD;

/**
 * Servlet implementation class Initialisation
 */
@WebServlet("/Initialisation")
public class Initialisation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Initialisation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		// récuperation des données saisies par l'administrateur
		String nom = request.getParameter("nom");
		String user = request.getParameter("user");
		String mail = request.getParameter("email");
		String pass = request.getParameter("pass");
		Float budget = Float.parseFloat(request.getParameter("budget"));
		
		// création des tables
		
		
		CreateBD.creerlestables();
		CreateBD.InitialisationBudget(budget);
		CreateBD.InitialisationResp(user, pass, mail, nom);
		
		
		//transmission à la JSP pour afficher
		request.setAttribute("nom", nom);
		request.setAttribute("user", user);
		request.setAttribute("mail", mail);
		request.setAttribute("pass", pass);
		request.setAttribute("budget",budget);
		
		
		this.getServletContext().getRequestDispatcher( "/WEB-INF/Resultat.jsp").forward( request, response );	
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
