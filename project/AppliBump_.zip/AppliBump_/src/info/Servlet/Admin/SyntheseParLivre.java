package info.Servlet.Admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Beans.MonFormulaire;
import ManipulationBD.RecupererLesDonnees;
import ManipulationBD.TesterLesDonnees;
import RequetesEtMessage.Requete;

/**
 * Servlet implementation class SyntheseParLivre
 */
@WebServlet("/SyntheseParLivre")
public class SyntheseParLivre extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SyntheseParLivre() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String isbn = request.getParameter("isbn");
		if(TesterLesDonnees.VerifierLIVRE(isbn)){
			List<MonFormulaire> type1 = RecupererLesDonnees.recupererFormulaire(Requete.requete4);
			
			for(int i = 0; i< type1.size(); i++){
				MonFormulaire f = type1.get(i);
				if(!(f.getISBN13().equals(isbn))){
					type1.remove(i);
					i--;	
				}
			}
			
			List<MonFormulaire> type2 = RecupererLesDonnees.recupererFormulaire(Requete.requete5);
		
			for(int i = 0; i< type2.size(); i++){
				MonFormulaire f = type2.get(i);
				if(!(f.getISBN13().equals(isbn))){
					type2.remove(i);
					i--;	
				}
			}
						
			List<MonFormulaire> type3 = RecupererLesDonnees.recupererFormulaire(Requete.requete6);
			
			for(int i = 0; i< type3.size(); i++){
				MonFormulaire f = type3.get(i);
				if(!(f.getISBN13().equals(isbn))){
					type3.remove(i);
					i--;
				}
			}	 
				String synthese = " "+ isbn+ " ";
				request.setAttribute("synthese", synthese);
				request.setAttribute("type1", type1);
				request.setAttribute("type2", type2);
				request.setAttribute("type3", type3);
				this.getServletContext().getRequestDispatcher( "/WEB-INF/Livre.jsp").forward( request, response );
						
		}
		else{
			 String titre ="Désolé, le livre correspondant à cet isbn : "+ isbn +" n'a pas été commandé.";	
			 request.setAttribute("titre", titre);
			 this.getServletContext().getRequestDispatcher( "/WEB-INF/Erreur.jsp").forward( request, response );
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
