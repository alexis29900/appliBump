package RequetesEtMessage;

public class Requete {
	
	/*
	 * les requetes sql
	 */
	public static String requete1 = "select EMAIL from RESPONSABLE";
	public  static String requete2 = "select USER,PASS,NOM from RESPONSABLE";
	public static String requete3 = "SELECT ID_PROF ,NOM,PRENOM FROM UTILISATEUR";
	
	//requete4 permet de selectionner toutes les nouvelles commandes
	public static String requete4="SELECT UTILISATEUR.ID_PROF,COMMANDE.NUM_COM,NOM,PRENOM,EMAIL,LIVRES.ISBN,QUANTITE,TITRE,AUTEUR,PRIX,URL,COTEBUMP,TYPE,URGENCE,DESTINATION,DATE_COMMANDE,DATE_VALIDATION,DATE_ACQUIS FROM UTILISATEUR, COMMANDE  , LIVRES, DETAIL where UTILISATEUR.ID_PROF = COMMANDE.ID_PROF AND COMMANDE.NUM_COM = DETAIL.NUM_COM	AND  DETAIL.ISBN = LIVRES.ISBN AND DATE_VALIDATION IS NULL";

	//requete5 permet de selectionner toutes les commandes en cours
	public static String requete5="SELECT UTILISATEUR.ID_PROF,COMMANDE.NUM_COM,NOM,PRENOM,EMAIL,LIVRES.ISBN,QUANTITE,TITRE,AUTEUR,PRIX,URL,COTEBUMP,TYPE,URGENCE,DESTINATION,DATE_COMMANDE,DATE_VALIDATION,DATE_ACQUIS FROM UTILISATEUR, COMMANDE  , LIVRES, DETAIL where UTILISATEUR.ID_PROF = COMMANDE.ID_PROF AND COMMANDE.NUM_COM = DETAIL.NUM_COM	AND  DETAIL.ISBN = LIVRES.ISBN AND DATE_VALIDATION IS NOT NULL AND DATE_ACQUIS IS NULL  ";

	//requete6 permet de selectionner toutes les commandes livrer
	public static String requete6="SELECT UTILISATEUR.ID_PROF,COMMANDE.NUM_COM,NOM,PRENOM,EMAIL,LIVRES.ISBN,QUANTITE,TITRE,AUTEUR,PRIX,URL,COTEBUMP,TYPE,URGENCE,DESTINATION,DATE_COMMANDE,DATE_VALIDATION,DATE_ACQUIS FROM UTILISATEUR, COMMANDE  , LIVRES, DETAIL where UTILISATEUR.ID_PROF = COMMANDE.ID_PROF AND COMMANDE.NUM_COM = DETAIL.NUM_COM	AND  DETAIL.ISBN = LIVRES.ISBN AND DATE_ACQUIS IS NOT NULL AND DATE_VALIDATION IS NOT NULL  ";

	public static String requete7="SELECT COMMANDE.ID_PROF, NUM_COM, NOM,PRENOM FROM COMMANDE, UTILISATEUR WHERE COMMANDE.ID_PROF= UTILISATEUR.ID_PROF";

	public static String message1 (String destinateur, String expediteur){
		
		String msg ="Bonjour "+destinateur+", Vous venez de récevoir une nouvelle commande de "+expediteur+" connectez vous pour decouvrir la commande";
	 return msg;
	}
	
	/*
	 * les titres des mails
	 */
	public static String titre1 ="Nouvelle Commande";
	
	public static String titre2 ="COMMANDE VALIDEE";
	
	public static String titre3 ="COMMANDE REFUSEE";
	public static String titre4 = "Modification de votre commande";
	public static String titre5 = "DES COMMANDES EN ATTENTE";
	
	/*
	 * les contenus des mails
	 */
	
	public static String message2(String nom ,String titre){
		String message ="Bonjour "+nom+ " , Votre commande du livre : "+ titre+" écrit par  a été validée. Vous n'allez pas tarder pour la recevoir. Bonne journée!!!";
		return message;
	}
	
	public static String message3(String nom){
		String msg ="Bonjour "+nom+" votre commande a été rejeter, Veuillez contacter l'administrateur pour en savoir davantage. bien cordialement ";
		return msg;
	}
	
	public static String message4 (String nom){
		String message ="Bonjour "+nom+", Votre commande vient d'etre modifié. Veuillez contacter l'administrateur pour en savoir davantage. bien à vous";
		return message;
	}
	
public static String message5 (String destinateur){
		
		String msg ="Bonjour "+destinateur+",il y a des commandes en attendent. connectez vous pour decouvrir la commande";
	 return msg;
	}
}
