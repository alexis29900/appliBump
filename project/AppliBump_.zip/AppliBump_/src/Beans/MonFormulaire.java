package Beans;

/**
 * cette classe java, contient tous les champs d'un formulaire
 * @author marie
 *
 */
public class MonFormulaire {


	private String nom;
	private String prenom;
	private String email;
	private String ISBN13;
	private Float prix;
	private String book;
	private String statut;
	private String coteBump;
	private String destination;
	private String datecom;
	private int quantity;
	private String urgent;
	private String url;
	private String datevalidation;
	private String dateacquisition;
	private int numerocli;
	private int numerocom;
	
	public int getNumerocli() {
		return numerocli;
	}
	public void setNumerocli(int numerocli) {
		this.numerocli = numerocli;
	}
	public int getNumerocom() {
		return numerocom;
	}
	public void setNumerocom(int numerocom) {
		this.numerocom = numerocom;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getISBN13() {
		return ISBN13;
	}
	public void setISBN13(String iSBN13) {
		ISBN13 = iSBN13;
	}
	public Float getPrix() {
		return prix;
	}
	public void setPrix(Float prix) {
		this.prix = prix;
	}
	public String getBook() {
		return book;
	}
	public void setBook(String book) {
		this.book = book;
	}
	public String getStatut() {
		return statut;
	}
	public void setStatut(String statut) {
		this.statut = statut;
	}
	public String getCoteBump() {
		return coteBump;
	}
	public void setCoteBump(String coteBump) {
		this.coteBump = coteBump;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDatecom() {
		return datecom;
	}
	public void setDatecom(String datecom) {
		this.datecom = datecom;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getUrgent() {
		return urgent;
	}
	public void setUrgent(String urgent) {
		this.urgent = urgent;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getDatevalidation() {
		return datevalidation;
	}
	public void setDatevalidation(String datevalidation) {
		this.datevalidation = datevalidation;
	}
	public String getDateacquisition() {
		return dateacquisition;
	}
	public void setDateacquisition(String dateacquisition) {
		this.dateacquisition = dateacquisition;
	}
}
