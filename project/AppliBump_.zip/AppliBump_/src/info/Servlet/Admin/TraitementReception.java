package info.Servlet.Admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ManipulationBD.Budget;
import ManipulationBD.ModificationDonnees;
import ManipulationBD.RecupererLesDonnees;
import RequetesEtMessage.Requete;

/**
 * Servlet implementation class TraitementReception
 */
@WebServlet("/TraitementReception")
public class TraitementReception extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TraitementReception() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int numero = Integer.parseInt( request.getParameter("valider"));
		ModificationDonnees.ReceptionnerLivre(numero);

		String message="un nouveau utilisateur vient de recevoir le livre";
		request.setAttribute("message", message);
			
		//on affiche le budget à l'ecran
		Float budget = Budget.VOIRBUDGET();
		request.setAttribute("budget", budget);
		
		//statistique
		int New = RecupererLesDonnees.ResumerCommande(Requete.requete4);
		int Valider = RecupererLesDonnees.ResumerCommande(Requete.requete5);
		
		request.setAttribute("New", New);
		request.setAttribute("Valider", Valider);
		
	
	this.getServletContext().getRequestDispatcher( "/WEB-INF/AccueilAdmin.jsp").forward( request, response );
					
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
