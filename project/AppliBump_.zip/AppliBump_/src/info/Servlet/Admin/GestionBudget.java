package info.Servlet.Admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ManipulationBD.Budget;
import ManipulationBD.RecupererLesDonnees;
import RequetesEtMessage.Requete;

/**
 * Servlet implementation class GestionBudget
 */
@WebServlet("/GestionBudget")
public class GestionBudget extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GestionBudget() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//on recupere le nouveau budget 
		Float Nouveaubudget =  Float.parseFloat( request.getParameter("revenu"));
		Budget.MODIFYBUDGET(Nouveaubudget);
		
		//message à afficher à l'ecran
		String message="Votre budget a été mis à jour";
		request.setAttribute("message", message);
		
		//statistique
		int New = RecupererLesDonnees.ResumerCommande(Requete.requete4);
		int Valider = RecupererLesDonnees.ResumerCommande(Requete.requete5);
		request.setAttribute("New", New);
		request.setAttribute("Valider", Valider);
		
		//affichage du budget
		Float budget = Budget.VOIRBUDGET();
		request.setAttribute("budget", budget);

		//transmission à la JSP pour afficher le menu administrateur
		this.getServletContext().getRequestDispatcher( "/WEB-INF/AccueilAdmin.jsp").forward( request, response );
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
