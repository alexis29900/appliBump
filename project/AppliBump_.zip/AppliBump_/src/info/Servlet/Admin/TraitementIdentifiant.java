package info.Servlet.Admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ManipulationBD.IdentifiantAdministrateur;
import ManipulationBD.TesterLesDonnees;

/**
 * Servlet implementation class TraitementIdentifiant
 */
@WebServlet("/TraitementIdentifiant")
public class TraitementIdentifiant extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TraitementIdentifiant() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	String nom = request.getParameter("name");
	String mail = request.getParameter("mail");
	String user = request.getParameter("username");
	String user2 = request.getParameter("username2");
	String oldpass = request.getParameter("oldpass");
	String newpass = request.getParameter("newpass");
	String confpass = request.getParameter("confpass");
	
	if(newpass.equals(confpass)){		
		if (TesterLesDonnees.ConnexionAdmin(user, oldpass)){
			IdentifiantAdministrateur.SupprimerAdmin(user);
			IdentifiantAdministrateur.AjoutAdmin(user2, newpass,nom,mail);
			
			String error ="Vos identifiants ont été modifiés";
			request.setAttribute("error", error);
			
			this.getServletContext().getRequestDispatcher( "/index.jsp").forward( request, response );
		}
		else {
			String message = "Username or Password incorrect";
			request.setAttribute("message", message);
			this.getServletContext().getRequestDispatcher( "/WEB-INF/MofierIdentifiant.jsp").forward( request, response );
		}
	}
	else{
		String message = "les deux mots de passe ne correspondent pas";
		request.setAttribute("message", message);
		this.getServletContext().getRequestDispatcher( "/WEB-INF/MofierIdentifiant.jsp").forward( request, response );
	}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
