package ManipulationBD;

import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import Beans.MonFormulaire;
import Mail.Email;
import RequetesEtMessage.Requete;

public class ModificationDonnees {

	/**
	 *  valider une commande
	 * @param numerocommande est le numero d'une commande non validé par l'administrateur
	 * @return true si la commande a été validé, sinon false
	 */
	public static boolean ValiderCommande(int numerocommande){
		
		/*
		 * on recupere la liste de toutes les commandes non validées
		 */
		String requete= Requete.requete4;
		boolean valide= false;
		List<MonFormulaire> liste = RecupererLesDonnees.recupererFormulaire(requete);
		MonFormulaire f = new MonFormulaire();
		for(int i =0; i<liste.size();i++){
			MonFormulaire temporaire = liste.get(i);
			if(numerocommande == temporaire.getNumerocom()){
				f= temporaire;
				break;
			}
		}
		/*
		 * on verifie si le budget restant permet de valider la commande
		 */
		Float budget = Budget.VOIRBUDGET();
					
		if (budget>=(f.getQuantity()*f.getPrix())){
			valide = true;
			Float reste = f.getQuantity()*f.getPrix();
			Budget.REDUIREBUDGET(reste);
						  
		  //on envoie un mail à l'utilisateur pour lui faire par du statut de sa commande
			String titre = Requete.titre2;
		    String message =Requete.message2(f.getNom(), f.getBook());						 
			try{
				 Email.sendEmail(f.getEmail(), titre, message);
				}
			catch(Exception e){}										 
						 
			// on cr�e l'objet en passant en param�tre une cha�ne representant le format 
			 SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd" ); 
			 //r�cup�ration de la date courante 
			 Date currentTime_1 = new Date(); 
			//on cr�e la cha�ne � partir de la date  
			 String dateValidation = formatter.format(currentTime_1);
						 
			 java.sql.Connection connexion=Connexion.connectMy();
			  try {       	
			          PreparedStatement preparedStatement = connexion.prepareStatement("UPDATE COMMANDE set DATE_VALIDATION ='"+dateValidation+"' WHERE NUM_COM = '" +numerocommande+"'");
			          preparedStatement.executeUpdate();
			           connexion.close();
			       } catch (Exception e) {
			                e.printStackTrace();
			            }
					}
		return valide;
	}
	
	/**
	 * Receptionner un nouveau Livre
	 * @param numerocommande est le numero d'une commande
	 * pre: la commande a déjà été validée
	 * post : la commande est livrée
	 */
	public static void ReceptionnerLivre(int numerocommande )
	{
					// on cr�e l'objet en passant en param�tre une cha�ne representant le format 
					 SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd" ); 
					 //r�cup�ration de la date courante 
					 Date currentTime_1 = new Date(); 
					 //on cr�e la cha�ne � partir de la date  
					 String datereception = formatter.format(currentTime_1);
					 
					
					 java.sql.Connection connexion=Connexion.connectMy();
			            try {       	
			                PreparedStatement preparedStatement = connexion.prepareStatement("UPDATE COMMANDE set DATE_ACQUIS ='"+datereception+"' WHERE NUM_COM = '" +numerocommande+"'");
			                preparedStatement.executeUpdate();
			                connexion.close();
			            } catch (Exception e) {
			                e.printStackTrace();
			            }
	}
	/**
	 *  supprimer une commande dans la base de donnée
	 * @param numerocommande est le numero d'une commande
	 * pre : la commande existe dans la base de donnée
	 * post : la demande a été rejetté par l'administrateur, et donc la commande n'existe plus dans la base de donnée
	 */
	public static void SupprimerCommande(int numerocommande){
		
		/*
		 * on recupere la liste de toutes les commandes non validées, puis on supprime celle dont le numéro de commande correspond au parametre 
		 */
		String requete= Requete.requete4;
		List<MonFormulaire> liste = RecupererLesDonnees.recupererFormulaire(requete);
		
		MonFormulaire f = new MonFormulaire();
		for(int i =0; i<liste.size();i++){
			MonFormulaire temporaire = liste.get(i);
			if(numerocommande == temporaire.getNumerocom()){
				f= temporaire;
				break;
			}
		}
					String titre = Requete.titre3;
					String message  = Requete.message3(f.getNom());
					
					//on envoie un mail à l'utilisateur pour lui faire par du statut de sa commande
					 try{
							Email.sendEmail(f.getEmail(), titre, message);
						}
						catch(Exception e){}
					
					 java.sql.Connection connexion=Connexion.connectMy();
			            try {       	
			                PreparedStatement preparedStatement = connexion.prepareStatement("DELETE FROM DETAIL WHERE NUM_COM = " +numerocommande+" ");
			                preparedStatement.executeUpdate();
			                PreparedStatement preparedStatement2 = connexion.prepareStatement("DELETE FROM COMMANDE WHERE NUM_COM = " +numerocommande+"");
			                preparedStatement2.executeUpdate();
			                connexion.close();
			            } catch (Exception e) {
			                e.printStackTrace();
			            }
		}
	
	/**
	 * modifier le contenu d'une commande
	 * @param f est le formulaire à modifier
	 */
	
	public static void ModifierCommande(MonFormulaire f){
		
		 java.sql.Connection connexion=Connexion.connectMy();
		 //exécution des requetes
         try {       	
             PreparedStatement preparedStatement = connexion.prepareStatement("DELETE FROM DETAIL WHERE NUM_COM = " +f.getNumerocom()+" ");
             preparedStatement.executeUpdate();
             PreparedStatement preparedStatement2 = connexion.prepareStatement("DELETE FROM COMMANDE WHERE NUM_COM = " +f.getNumerocom()+"");
             preparedStatement2.executeUpdate();
             connexion.close();
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         Connexion.AjouterFormulaire(f);	
	}
	
}

