package info.Servlet.Admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Beans.MonFormulaire;
import ManipulationBD.RecupererLesDonnees;
import ManipulationBD.TesterLesDonnees;
import RequetesEtMessage.Requete;

/**
 * Servlet implementation class SyntheseParUtilisateur
 */
@WebServlet("/SyntheseParUtilisateur")
public class SyntheseParUtilisateur extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SyntheseParUtilisateur() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String nom = request.getParameter("nom");
		 String prenom = request.getParameter("prenom");
		 
		 int identifiantKey =TesterLesDonnees.TROUVERIDENTIFIANT(nom, prenom);
		 if (identifiantKey==0){
			 String titre ="l'utilsateur "+nom+" "+prenom+ " n'a pas été trouvé.";	
			 request.setAttribute("titre", titre);
			 this.getServletContext().getRequestDispatcher( "/WEB-INF/Erreur.jsp").forward( request, response );
		 }
		 else
		 {
			 			 
			 List<MonFormulaire> type1 = RecupererLesDonnees.recupererFormulaire(Requete.requete4);
				for(int i = 0; i< type1.size(); i++){
					MonFormulaire t = type1.get(i);
					if((!(t.getNom().equals(nom)))&&(!(t.getPrenom().equals(prenom)))){
						type1.remove(i);
						i--;	
					}
				}
				
				List<MonFormulaire> type2 = RecupererLesDonnees.recupererFormulaire(Requete.requete5);
			
				for(int i = 0; i< type2.size(); i++){
					MonFormulaire t = type2.get(i);
					if((!(t.getNom().equals(nom)))&&(!(t.getPrenom().equals(prenom)))){
						type2.remove(i);
						i--;	
					}
				}
							
				List<MonFormulaire> type3 = RecupererLesDonnees.recupererFormulaire(Requete.requete6);
				
				for(int i = 0; i< type3.size(); i++){
					MonFormulaire t = type3.get(i);
					if((!(t.getNom().equals(nom)))&&(!(t.getPrenom().equals(prenom)))){
						type3.remove(i);
						i--;
					}
				}	 
					
					request.setAttribute("type1", type1);
					request.setAttribute("type2", type2);
					request.setAttribute("type3", type3);
			 
		 String synthese = "Synthèse de "+prenom+" "+nom+" ";
		 request.setAttribute("synthese", synthese);
		 this.getServletContext().getRequestDispatcher( "/WEB-INF/Utilisateur.jsp").forward( request, response );
		 }	
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
