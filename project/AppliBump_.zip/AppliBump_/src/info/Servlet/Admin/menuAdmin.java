package info.Servlet.Admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Beans.MonFormulaire;
import ManipulationBD.Budget;
import ManipulationBD.RecupererLesDonnees;
import RequetesEtMessage.Requete;

/**
 * Servlet implementation class menuAdmin
 */
@WebServlet("/menuAdmin")
public class menuAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
    

	/*
	 * les reponses sont les differentes onglets du menu administrateur
	 */
	String reponse0 ="MODIFIER VOS IDENTIFIANTS";
	String reponse1 ="MODIFIER LE BUDGET";
	String reponse2 = "NOUVELLES COMMANDES";
	String reponse3 ="COMMANDES EN COURS";
	String reponse4 ="COMMANDES LIVREES";
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public menuAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String retour = request.getParameter("reponse");
		
		//statistique
		int New = RecupererLesDonnees.ResumerCommande(Requete.requete4);
		int Valider = RecupererLesDonnees.ResumerCommande(Requete.requete5);
		request.setAttribute("New", New);
		request.setAttribute("Valider", Valider);
		
		//affichage du budget
		Float budget = Budget.VOIRBUDGET();
		request.setAttribute("budget", budget);

		
		/*
		* permet à l'administrateur de modifier ses parametres de connexion
		  */
		if(retour.equals(reponse0)){
			String message = "";
			request.setAttribute("message", message);
			this.getServletContext().getRequestDispatcher( "/WEB-INF/MofierIdentifiant.jsp").forward( request, response );	
		}
		else 
		{
			
		// permet à l'administrateur de modifier le budget
		if(retour.equals(reponse1)){			
			this.getServletContext().getRequestDispatcher( "/WEB-INF/budget2.jsp").forward( request, response );	
		}
		else{
			// permet à l'administrateur de voir toutes les nouvelles commandes
			if(retour.equals(reponse2)){
									
				//TRANSMISSION DU RESULTAT
				List<MonFormulaire> f = RecupererLesDonnees.recupererFormulaire(Requete.requete4);
				if(f.isEmpty()){
					String message="Pas de nouvelles commandes";
					request.setAttribute("message", message);
					this.getServletContext().getRequestDispatcher( "/WEB-INF/AccueilAdmin.jsp").forward( request, response );
				}
				else{
					request.setAttribute("f",f);
				this.getServletContext().getRequestDispatcher( "/WEB-INF/commande1.jsp").forward( request, response );	
				}
			}
			else{
				// les commandes en cours
				if(retour.equals(reponse3)){
					
					List<MonFormulaire> f = RecupererLesDonnees.recupererFormulaire(Requete.requete5);
					if(f.isEmpty()){
						String message="Aucune Commande en cours";
						request.setAttribute("message", message);
						this.getServletContext().getRequestDispatcher( "/WEB-INF/AccueilAdmin.jsp").forward( request, response );
					}
					else{
						String titre ="COMMANDES EN COURS";
						request.setAttribute("titre", titre);
						request.setAttribute("f",f);
					this.getServletContext().getRequestDispatcher( "/WEB-INF/commande2.jsp").forward( request, response );	
					}
				}
				else{
					//les commandes reçues
					if(retour.equals(reponse4)){
							
						List<MonFormulaire> f = RecupererLesDonnees.recupererFormulaire(Requete.requete6);
						if(f.isEmpty()){
							String message="pas de livres receptionnés";
							request.setAttribute("message", message);
							this.getServletContext().getRequestDispatcher( "/WEB-INF/AccueilAdmin.jsp").forward( request, response );
						}
						else{
							String titre ="Livres achetés";
							request.setAttribute("titre", titre);
							request.setAttribute("f",f);
						this.getServletContext().getRequestDispatcher( "/WEB-INF/commande2.jsp").forward( request, response );	
						}
						}
					else {
						String error ="Veuillez remplir tous les champs";
						request.setAttribute("error", error);
						this.getServletContext().getRequestDispatcher( "/WEB-INF/MofierIdentifiant.jsp").forward( request, response );
					}
						
					}
					}
				}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
