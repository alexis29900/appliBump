package info.Servlet.Formulaire;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Beans.MonFormulaire;
import Mail.Email;
import ManipulationBD.Connexion;
import ManipulationBD.TesterLesDonnees;
import RequetesEtMessage.Requete;

/**
 * Servlet implementation class TraitementFormulaire
 */
@WebServlet("/TraitementFormulaire")
public class TraitementFormulaire extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TraitementFormulaire() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		// récupération du formulaire
		
				 String nom = request.getParameter("nom");
				 String prenom = request.getParameter("prenom");
				 String email = request.getParameter("email");
				 
				 String ISBN13 = request.getParameter("isbn");
				 Float prix = Float.parseFloat(request.getParameter("prix"));
				 String book = request.getParameter("titre"); 
				 String url = request.getParameter("url");
				 
				 int quantity = Integer.parseInt( request.getParameter("quantite"));
				 String valeur = request.getParameter("urgent");
				 String statut = request.getParameter("statut");
				 String coteBump = request.getParameter("coteBump");
				 String destination = request.getParameter("destination");
				
				 
				// on cr�e l'objet en passant en param�tre une cha�ne representant le format 
				 SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd" ); 
				 //récupération de la date courante 
				 Date currentTime_1 = new Date(); 
				 //on crée la cha�ne à partir de la date  
				 String datecom = formatter.format(currentTime_1);
				
				 
				 // création d'un bean utilisateur et initialisation avec les données récupérées sur le formulaire
				 MonFormulaire prof = new MonFormulaire();
				 prof.setNom(nom);
				 prof.setPrenom(prenom);
				 prof.setEmail(email);		 
				 
				 prof.setISBN13(ISBN13);
				 prof.setPrix(prix);
				 prof.setBook(book);
				 	  
				 prof.setQuantity(quantity);  
				 prof.setDatecom(datecom);
				 prof.setUrgent(valeur);
				 prof.setStatut(statut);
				 prof.setCoteBump(coteBump);
				 prof.setDestination(destination);
				 prof.setUrl(url);
				
				 /*
				  * Traitement des cas d'erreur */
				 if((ISBN13.length()<10))
				 {
					// message � afficher	
					String message="ISBN incorrect!!!";
					request.setAttribute("texteAfiche",message );
					request.setAttribute("prof", prof);
					//transmission � la JSP pour afficher
					this.getServletContext().getRequestDispatcher( "/WEB-INF/Modifierformulaire.jsp").forward( request, response );
								
				 }
				 else { 
					 	//enregistrement du formulaire dans la base de donnee
					 	Connexion.AjouterFormulaire(prof);
					 	String message="Votre commande a été prise en compte. Voici les données que vous avez saisi";	
						request.setAttribute("texteAfiche", message);
						request.setAttribute("prof",prof );
						
						//notification au responsable
						String messageAenvoyer = Requete.message1(TesterLesDonnees.AdresseUserNameAdmin(), prof.getNom());
						String sujet= Requete.titre1;
						try{
							Email.sendEmail(TesterLesDonnees.AdresseMailAdmin(), sujet, messageAenvoyer);
						}
						catch(Exception e){}				
						
						//transmission à la JSP pour afficher le formuliare remplit
						this.getServletContext().getRequestDispatcher( "/WEB-INF/Resultat.jsp").forward( request, response );				
						
				 }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
