package info.Servlet.Admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Beans.MonFormulaire;
import ManipulationBD.Budget;
import ManipulationBD.ModificationDonnees;
import ManipulationBD.RecupererLesDonnees;
import RequetesEtMessage.Requete;

/**
 * Servlet implementation class ValiderCommandeLivre
 */
@WebServlet("/ValiderCommandeLivre")
public class ValiderCommandeLivre extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValiderCommandeLivre() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int numerocommande = Integer.parseInt( request.getParameter("valider"));
		//affichage du budget
		Float budget = Budget.VOIRBUDGET();
		request.setAttribute("budget", budget);
		
		//statistique
		int New = RecupererLesDonnees.ResumerCommande(Requete.requete4);
		int Valider = RecupererLesDonnees.ResumerCommande(Requete.requete5);
		request.setAttribute("New", New);
		request.setAttribute("Valider", Valider);
		
		if(ModificationDonnees.ValiderCommande(numerocommande)){					
			 List<MonFormulaire> f = RecupererLesDonnees.recupererFormulaire(Requete.requete4);
			 if(f.isEmpty()){
				 String message="Pas de nouvelles commandes";
				 request.setAttribute("message", message); 				 
					
					this.getServletContext().getRequestDispatcher( "/WEB-INF/AccueilAdmin.jsp").forward( request, response );
			 }
			 else{
				 
				 request.setAttribute("f",f);
				 this.getServletContext().getRequestDispatcher( "/WEB-INF/commande1.jsp").forward( request, response );	
			 }
		}
		else{
			
			String message="Le budget restant ne vous permet pas de valider cette commande";
			request.setAttribute("message", message);
		
			this.getServletContext().getRequestDispatcher( "/WEB-INF/AccueilAdmin.jsp").forward( request, response );
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
