package Mail;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Email {

	/**
	 * Envoi d'un email utilisant une socket SSL .
	 * @param to celui ou ceux qui doivent recevoir l'email (séparation des adresses par des virgules)
	 * @param subject sujet de l'email
	 * @param content contenu de l'email
	 * @throws AddressException les adresses de destinations sont incorrectes
	 * @throws MessagingException une erreur est survenue à l'envoi de l'email
	 */	
	
	public static void sendEmail(String to,String subject,String content) throws AddressException, MessagingException {
		// smtp properties
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.ssl.trust", "smtp.gmail.com");

		// authentification
		Session session = Session.getDefaultInstance(props,
			new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("bumpprojet@gmail.com","Bump2015");
				}
			}
		);

		// construction message
		Message message = new MimeMessage(session);
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
		message.setSubject(subject);
		message.setContent(content, "text/html; charset=ISO-8859-1");

		// send email
		Transport.send(message);

	}

}

/*
 * 
 * 					 try {
							Email.sendEmail("jessicamwinkeu@hotmail.fr", "Texte", "Salut Belle Dame");
						} catch (AddressException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (MessagingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} 
 * */


