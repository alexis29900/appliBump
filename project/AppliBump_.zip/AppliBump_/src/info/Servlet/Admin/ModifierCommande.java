package info.Servlet.Admin;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Beans.MonFormulaire;
import ManipulationBD.RecupererLesDonnees;
import RequetesEtMessage.Requete;

/**
 * Servlet implementation class ModifierCommande
 */
@WebServlet("/ModifierCommande")
public class ModifierCommande extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModifierCommande() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int numero = Integer.parseInt( request.getParameter("modifier"));
		List<MonFormulaire> proff = RecupererLesDonnees.recupererFormulaire(Requete.requete4);
		
		
		for(int i = 0; i<proff.size();i++){
			MonFormulaire prof = proff.get(i);
			if(prof.getNumerocom()== numero){
				request.setAttribute("prof", prof);				
				break;
			}
		}

		// message � afficher	
		String message="ISBN incorrect!!!";
		request.setAttribute("texteAfiche",message );
		
		
		//transmission � la JSP permettant à l'admistrateur de modifier une commande
		this.getServletContext().getRequestDispatcher( "/WEB-INF/Modifierformulaire.jsp").forward( request, response );
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
