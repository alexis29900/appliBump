package ManipulationBD;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Budget {

	/**
	 * Afficher le budget actuel
	 * @return le budget restant
	 */
	public static Float VOIRBUDGET (){
		java.sql.Connection connexion = Connexion.connectMy();
		Float Budget = new Float(0.01);;
		try {
			  Statement statement = connexion.createStatement();
	          // Exécution de la requête
			  ResultSet resultat = statement.executeQuery("select SUM(BUDGET)as RESTE FROM REVENU");
	          // Récupération des données   
			     while (resultat.next()) {
	        	 Budget = resultat.getFloat("RESTE");
	          connexion.close();
			     }
	      } catch (Exception e) { }
		  return Budget;		  
	      }

	/**
	 * Modfier le budget
	 * @param budget la somme à ajouter
	 */
	public static void MODIFYBUDGET(Float budget){
		java.sql.Connection connexion=Connexion.connectMy();
		Float b = VOIRBUDGET()+ budget;
		
        try {  
        	
            PreparedStatement preparedStatement = connexion.prepareStatement("UPDATE REVENU set  BUDGET ='"+b+"'");
            preparedStatement.executeUpdate();
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	/**
	 * Reduire le budget
	 * @param budget la somme à soustraire
	 */
	public static void REDUIREBUDGET(Float budget){
		java.sql.Connection connexion=Connexion.connectMy();
		Float b = VOIRBUDGET()- budget;
		
        try {       	
            PreparedStatement preparedStatement = connexion.prepareStatement("UPDATE REVENU set  BUDGET ='"+b+"'");
            preparedStatement.executeUpdate();
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	/*
		public static void main(String [] args){
			Float i = VOIRBUDGET();
			System.out.println(i);
			MODIFYBUDGET(1000);
			i = VOIRBUDGET();
			System.out.println(i);
		}
		*/
}
