package ManipulationBD;

import java.sql.PreparedStatement;


public class IdentifiantAdministrateur {
	
	/**
	 * enregistrer les données de connection de l'administrateur
	 * @param nom est le username de l'administrateur
	 * @param pass est le mot de passe
	 * @param name est le nom de l'administrateur
	 * @param mail est l'email de l'administrateur
	 */
	public static void AjoutAdmin(String nom, String pass, String name, String mail){
		java.sql.Connection connexion=Connexion.connectMy();
		//exécution des requetes
        try {       	
            PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO RESPONSABLE(USER,PASS,EMAIL,NOM) VALUES(?, ?,?,?);");
            preparedStatement.setString(1,nom);
            preparedStatement.setString(2, pass);
            preparedStatement.setString(3,mail);
            preparedStatement.setString(4,name);
            preparedStatement.executeUpdate();
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	
	
	/**
	 * supprimer les anciennes données de connexion de l'administrateur
	 * @param user est le username  de l'administrateur
	 */
	public static void SupprimerAdmin(String user){
		
		 java.sql.Connection connexion=Connexion.connectMy();
        try {       	
            PreparedStatement preparedStatement = connexion.prepareStatement("DELETE FROM RESPONSABLE WHERE USER = '"+user+"'");
            preparedStatement.executeUpdate();
            connexion.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
}   
	
	  /*
	   * public static void main(String args []){
	   */
		 // SupprimerAdmin("bump");
		  //AjoutAdmin("bump", "bump", "Jessica", "jessicamwinkeu@hotmail.fr");
		  
	  


