package ManipulationBD;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Beans.MonFormulaire;

public class RecupererLesDonnees {
	
	/**
	 * trouver l'ISBN commandé au sein d'une commande
	 * @param numerocommande indique le numéro d'une commande
	 * @return l'ISBN du livre commandé
	 */
	public static String ISBNcommande (int numerocommande){
		java.sql.Connection connexion = Connexion.connectMy();
		String isbn=" ";
		try {
			  Statement statement = connexion.createStatement();
			  //éxécution de la requete
			  ResultSet resultat = statement.executeQuery("select ISBN from DETAIL where NUM_COM = "+numerocommande+" ");
			  //recupération des résultats
	          while (resultat.next()) {  
	        	 isbn =resultat.getString("ISBN");
	        	 /*System.out.println(isbn);*/
	        	 break;
	            }
	          connexion.close();
	      } catch (Exception e) { }
		  return isbn;		  
	      }
	/**
	 * renvoyer une selection de la liste de toutes les commandes repondant à une condition bien précise
	 * @param requete la condiion de selection
	 * @return la liste des commandes conforme à la requete 
	 */
	public static  List<MonFormulaire> recupererFormulaire(String requete){
		List<MonFormulaire> utt = new ArrayList<MonFormulaire>();
		
		java.sql.Connection connexion = Connexion.connectMy();
		try {
			  Statement statement = connexion.createStatement();
			  ResultSet resultat = statement.executeQuery(requete);

	         //on récupère le résultat
	          while (resultat.next()) {
	        	  int id=resultat.getInt("ID_PROF");
	        	  int key= resultat.getInt("NUM_COM");
	        	  String nom = resultat.getString("NOM");
	        	  String prenom=resultat.getString("PRENOM");
	              String email=resultat.getString("EMAIL");
	              String isbn1=resultat.getString("ISBN");
        		  String titre=resultat.getString("TITRE");
        		  Float prix =resultat.getFloat("PRIX");
        	        		
        		  String dateacquis =resultat.getString("DATE_ACQUIS");
	              String datevalid =resultat.getString("DATE_VALIDATION");
	              String datecom =resultat.getString("DATE_COMMANDE");
	              int qte = resultat.getInt("QUANTITE");
	                String type =resultat.getString("TYPE");	                
	                String destination =resultat.getString("DESTINATION");
	                String cotebump =resultat.getString("COTEBUMP");
	                String urgence =resultat.getString("URGENCE");
	                String url =resultat.getString("URL");
	                 
	        	  //sauvegarde
	        		  MonFormulaire ut= new MonFormulaire();
	        		  ut.setNumerocli(id);
	        		  ut.setNumerocom(key);
	        		  ut.setNom(nom);
	        		  ut.setPrenom(prenom);
	        		  ut.setEmail(email);
	        		  ut.setBook(titre);
	        		  ut.setISBN13(isbn1);
	        		  ut.setPrix( prix);
	        		  ut.setDateacquisition(dateacquis);
		              ut.setDatecom(datecom);
		              ut.setDatevalidation(datevalid);
		              ut.setQuantity(qte);	                
		              ut.setStatut(type);
		              ut.setUrgent(urgence);
		              ut.setDestination(destination);
		              ut.setCoteBump(cotebump);
		              ut.setUrl(url);
		                   
	        		  
	        		utt.add(ut); 
	        	  }
	          connexion.close();
	            }  
	       catch (Exception e) { }		 	
		
		//on renvoie toute la liste
		return utt;
	}
	/**
	 * renvoyer la taille d'une liste
	 * @param requete condition de selection
	 * @return la taille d'une liste
	 */
	public static int ResumerCommande (String requete){
		int id=recupererFormulaire(requete).size();
		return id;
	}


}
