package ManipulationBD;

import java.sql.ResultSet;
import java.sql.Statement;

import RequetesEtMessage.Requete;

public class TesterLesDonnees {

	/**
	 *vérifier comme le nom l'indique si un livre existe dejà dans la base de donnée
	 * @param isbn est l'iSBN du livre qu'on cherche
	 * @return true si le livre existe, sinon false
	 */
	
	public static boolean VerifierLIVRE ( String isbn){
		java.sql.Connection connexion = Connexion.connectMy();
		boolean livreExiste = false;
		try {
			  Statement statement = connexion.createStatement();
	          // Exécution de la requête
			  ResultSet resultat = statement.executeQuery("SELECT ISBN FROM LIVRES");

	          // Récupération des données   			  
	          while (resultat.next()) {
	              String isbnlivre = resultat.getString("ISBN");
	              if (isbn.equals(isbnlivre)) {
	            	  livreExiste =true;
	            	  break;}
	            }
	          connexion.close();

	      } catch (Exception e) { }
		  return livreExiste;		  
	      } 	
	
	/**
	 * trouver le numero de commande d'un client 
	 * @param identifiant est l'identifiant d'un client sauvegardé dans la base de donnée
	 * @param nom est le nom du client
	 * @param prenom le prenom du client
	 * @return 0 si le client n'a pas passé de nouvelles commandes, sinon le numero de la commande du client
	 */

	
	public static int TROUVERNUMEROCOMMANDE (int identifiant, String nom, String prenom ){
		java.sql.Connection connexion = Connexion.connectMy();
		int cle = 0;
		try {
			  Statement statement = connexion.createStatement();
	          // Exécution de la requête
			  ResultSet resultat = statement.executeQuery(Requete.requete7);

	          // Récupération des données   
			     while (resultat.next()) {
			    	 int id =resultat.getInt("ID_PROF");
			    	 String n = resultat.getString("NOM");
			    	 String p = resultat.getString("PRENOM");
			    	 	if ((id == identifiant) &&(n.equals(nom))&&(p.equals(prenom))){ 
			    	 			cle = resultat.getInt("NUM_COM");
			    	 			break;
			    	 		}
			     		}
			     connexion.close();
	      	}
			catch (Exception e) { }
		  	return cle;		  
	      }
	/**
	 * chercher un client dans la base de donnée
	 * @param nom est le nom du client
	 * @param prenom est le prenom du client
	 * @return 0 si le client n'existe pas, sinom sont identifiant
	 */
	
	public static int TROUVERIDENTIFIANT(String nom, String prenom){
		java.sql.Connection connexion = Connexion.connectMy();
		int cle =0;
		try {
			  Statement statement = connexion.createStatement();
	          // Exécution de la requête
			  ResultSet resultat = statement.executeQuery(Requete.requete3);

	          // Récupération des données   			  
	          while (resultat.next()) {
	             String nom1 = resultat.getString("NOM");
	             /*System.out.println(nom1);*/
	             String prenom1 = resultat.getString("PRENOM");
	             /*System.out.println(prenom1);*/
	              if ((nom1.equals(nom))&&(prenom1.equals(prenom))) 
	              	{ 
	            	  cle = resultat.getInt("ID_PROF"); 
	            	  break;
	            	  }
	            }
	          connexion.close();
	      } catch (Exception e) { }
		  return cle;		  
	      }

		/**
		 * se connecter sur l'espace admin
		 * @param nom est le username de l'administrateur
		 * @param pass est le password
		 * @return true si le nom et le pass sont corrects, sion false
		 */
		public static boolean ConnexionAdmin(String nom , String pass){
			
			java.sql.Connection connexion = Connexion.connectMy();
			boolean cle = false;
			try {
				  Statement statement = connexion.createStatement();
		          // Exécution de la requête
				  ResultSet resultat = statement.executeQuery(Requete.requete2);

		          // Récupération des données   
		          while (resultat.next()) {
		             String nom1 = resultat.getString("USER");
		             /*System.out.println(nom1);*/
		             String prenom1 = resultat.getString("PASS");
		             /*System.out.println(prenom1);*/
		              if ((nom1.equals(nom))&&(prenom1.equals(pass))) 
		              	{ 
		            	  cle = true;
		            	  break;
		            	  }
		            }
		          connexion.close();
		      } catch (Exception e) { }
			  return cle;
		}
	
		/**
		 * chercher l'adresse electronique de l'administrateur
		 * @return le mail de l'administrateur
		 */
		public static String AdresseMailAdmin(){
			java.sql.Connection connexion = Connexion.connectMy();
			String cle = "";
			try {
				  Statement statement = connexion.createStatement();
		          // Exécution de la requête
				  ResultSet resultat = statement.executeQuery(Requete.requete1);

		          // Récupération des données    
		          while (resultat.next()) {
		             String email = resultat.getString("EMAIL");
		             /*System.out.println(email);*/
		            	  cle = email;
		            	  break;
		            	  }
		          connexion.close();
		      } catch (Exception e) { }
			  return cle;			
		}
		/**
		 * chercher le nom de l'administrateur
		 * @return le nom de l'administrateur
		 */
		public static String AdresseUserNameAdmin(){
			java.sql.Connection connexion = Connexion.connectMy();
			String cle = "";
			try {
				  Statement statement = connexion.createStatement();
		          // Exécution de la requête
				  ResultSet resultat = statement.executeQuery(Requete.requete2);

		          // Récupération des données   
				  
		          while (resultat.next()) {
		             String nom = resultat.getString("Nom");
		             /*System.out.println(nom);*/
		            	  cle = nom;
		            	  break;
		            	  }
		          connexion.close();
		      } catch (Exception e) { }
			  return cle;			
		}
		
		
	/*public static void main(String [] args){
		 int key = TROUVERIDENTIFIANT("Kazadi","Deborah");
		 if(key==0){
			 System.out.println("cet utilisateur n'as pas était trouver dans la base de donnée");
		 }
		 else{
			 int NumCom = TROUVERNUMEROCOMMANDE(key,"Kazadi","Deborah" );
			 System.out.println(key+" "+NumCom);
		 }
		 if(VerifierLIVRE("9782212134438")){
			 System.out.println("ok");			 
		 }
		 else{
			 System.out.println("ko");
		 }
		
	}*/
	
}
